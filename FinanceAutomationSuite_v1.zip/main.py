import sys

from PySide6.QtWidgets import (
    QApplication,
    QMessageBox
)

from core.app_context import AppContext
from gui.main_window import MainWindow


def main():

    app = QApplication(sys.argv)

    context = None

    try:

        # =====================================================
        # APP CONTEXT
        # =====================================================

        context = AppContext()

        context.logger.title(
            "Finance Automation Suite Started"
        )

        # =====================================================
        # MAIN WINDOW
        # =====================================================

        window = MainWindow(context)
        window.show()

        return app.exec()

    except Exception as e:

        if context is not None:

            try:
                context.logger.exception(e)
            except Exception:
                pass

        QMessageBox.critical(
            None,
            "Application Error",
            str(e)
        )

        return 1


if __name__ == "__main__":

    sys.exit(main())