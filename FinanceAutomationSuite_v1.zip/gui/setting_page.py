from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QGroupBox,
    QGridLayout,
    QVBoxLayout,
    QHBoxLayout,
    QDoubleSpinBox,
    QSpinBox,
    QMessageBox
)


class SettingPage(QWidget):

    def __init__(self, context):

        super().__init__()

        self.context = context
        self.config = context.config
        self.logger = context.logger
        self.calibration = context.calibration

        self.position_labels = {}

        self.build_ui()
        self.load_settings()

    # =====================================================
    # BUILD UI
    # =====================================================

    def build_ui(self):

        layout = QVBoxLayout(self)

        title = QLabel("⚙ Settings")
        title.setStyleSheet(
            "font-size:18px;font-weight:bold;"
        )

        layout.addWidget(title)

        # =====================================================
        # AUTOMATION
        # =====================================================

        group = QGroupBox("Automation")

        grid = QGridLayout()

        self.click_delay = QDoubleSpinBox()
        self.click_delay.setDecimals(2)
        self.click_delay.setRange(0, 10)

        self.typing_speed = QDoubleSpinBox()
        self.typing_speed.setDecimals(2)
        self.typing_speed.setRange(0, 2)

        self.retry = QSpinBox()
        self.retry.setRange(1, 10)

        self.upload_speed = QSpinBox()
        self.upload_speed.setRange(50, 5000)
        self.upload_speed.setSingleStep(50)
        self.upload_speed.setSuffix(" KB/s")

        grid.addWidget(QLabel("Click Delay"), 0, 0)
        grid.addWidget(self.click_delay, 0, 1)

        grid.addWidget(QLabel("Typing Speed"), 1, 0)
        grid.addWidget(self.typing_speed, 1, 1)

        grid.addWidget(QLabel("Retry"), 2, 0)
        grid.addWidget(self.retry, 2, 1)

        grid.addWidget(QLabel("Upload Speed"), 3, 0)
        grid.addWidget(self.upload_speed, 3, 1)

        group.setLayout(grid)

        layout.addWidget(group)

        # =====================================================
        # CALIBRATION
        # =====================================================

        cal_group = QGroupBox("Calibration")

        cal_grid = QGridLayout()

        items = [
            ("Query", "query"),
            ("Checkbox", "checkbox"),
            ("Option", "option"),
            ("Attachment", "attachment"),
            ("New", "new"),
            ("Plus", "plus"),
            ("File Name", "file_name"),
            ("Open", "open"),
            ("Save", "save"),
            ("Exit 1", "exit1"),
            ("Exit 2", "exit2"),
            ("Error", "error"),
        ]

        for row, (label, key) in enumerate(items):

            cal_grid.addWidget(
                QLabel(label),
                row,
                0
            )

            pos = QLabel("-")
            pos.setAlignment(Qt.AlignCenter)

            self.position_labels[key] = pos

            cal_grid.addWidget(
                pos,
                row,
                1
            )

            btn = QPushButton("Capture")

            btn.clicked.connect(
                lambda _, k=key: self.capture(k)
            )

            cal_grid.addWidget(
                btn,
                row,
                2
            )

        cal_group.setLayout(cal_grid)

        layout.addWidget(cal_group)

        # =====================================================
        # BUTTON
        # =====================================================

        button_layout = QHBoxLayout()

        self.btn_save = QPushButton("Save")
        self.btn_reset = QPushButton("Reset")

        self.btn_save.clicked.connect(
            self.save_settings
        )

        self.btn_reset.clicked.connect(
            self.reset_settings
        )

        button_layout.addWidget(
            self.btn_save
        )

        button_layout.addWidget(
            self.btn_reset
        )

        layout.addLayout(
            button_layout
        )

        layout.addStretch()

    # =====================================================
    # LOAD
    # =====================================================

    def load_settings(self):

        self.click_delay.setValue(
            self.config.get_float(
                "click_delay",
                2.0
            )
        )

        self.typing_speed.setValue(
            self.config.get_float(
                "typing_speed",
                2.0
            )
        )

        self.retry.setValue(
            self.config.get_int(
                "retry",
                3
            )
        )

        self.upload_speed.setValue(
            self.config.get_int(
                "upload_speed",
                100
            )
        )

        # =============================
        # LOAD POSITION
        # =============================

        for key, label in self.position_labels.items():

            try:

                x, y = self.config.get_position(key)

                label.setText(
                    f"({x}, {y})"
                )

            except Exception:

                label.setText("-")

    # =====================================================
    # SAVE
    # =====================================================

    def save_settings(self):

        self.config.set(
            "click_delay",
            self.click_delay.value()
        )

        self.config.set(
            "typing_speed",
            self.typing_speed.value()
        )

        self.config.set(
            "retry",
            self.retry.value()
        )

        self.config.set(
            "upload_speed",
            self.upload_speed.value()
        )

        self.logger.info(
            "Settings saved."
        )

        QMessageBox.information(
            self,
            "Success",
            "Settings berhasil disimpan."
        )

    # =====================================================
    # RESET
    # =====================================================

    def reset_settings(self):

        self.config.reset()

        self.load_settings()

        self.logger.info(
            "Settings reset."
        )

        QMessageBox.information(
            self,
            "Reset",
            "Settings berhasil dikembalikan ke default."
        )

    # =====================================================
    # CAPTURE
    # =====================================================

    def capture(self, key):

        try:

            x, y = self.calibration.capture(
                key
            )

            self.position_labels[key].setText(
                f"({x}, {y})"
            )

            self.logger.info(
                f"Captured : {key} -> ({x},{y})"
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "Error",
                str(e)
            )