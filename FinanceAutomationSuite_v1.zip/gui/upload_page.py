from pathlib import Path

from PySide6.QtCore import Qt, QThread
from PySide6.QtWidgets import (
    QWidget,
    QFileDialog,
    QPushButton,
    QLabel,
    QTextEdit,
    QVBoxLayout,
    QHBoxLayout,
    QProgressBar,
)

from modules.upload_worker import UploadWorker


class UploadPage(QWidget):

    def __init__(self, context):

        super().__init__()

        # =====================================================
        # CONTEXT
        # =====================================================

        self.context = context
        self.config = context.config
        self.logger = context.logger

        # =====================================================
        # STATE
        # =====================================================

        self.excel_file = ""
        self.worker = None
        self.thread = None

        self.init_ui()

    # =====================================================
    # UI
    # =====================================================

    def init_ui(self):

        layout = QVBoxLayout(self)

        self.lbl_file = QLabel("Belum memilih file Excel")
        self.lbl_file.setAlignment(Qt.AlignLeft)

        self.btn_browse = QPushButton("Pilih Excel")
        self.btn_start = QPushButton("Start Upload")
        self.btn_stop = QPushButton("Stop")

        self.progress = QProgressBar()
        self.progress.setValue(0)

        self.log = QTextEdit()
        self.log.setReadOnly(True)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.btn_browse)
        button_layout.addWidget(self.btn_start)
        button_layout.addWidget(self.btn_stop)

        layout.addWidget(self.lbl_file)
        layout.addLayout(button_layout)
        layout.addWidget(self.progress)
        layout.addWidget(self.log)

        self.btn_browse.clicked.connect(self.browse_excel)
        self.btn_start.clicked.connect(self.start_upload)
        self.btn_stop.clicked.connect(self.stop_upload)

    # =====================================================
    # BROWSE EXCEL
    # =====================================================

    def browse_excel(self):

        file, _ = QFileDialog.getOpenFileName(
            self,
            "Pilih File Excel",
            "",
            "Excel Files (*.xlsx *.xls)"
        )

        if not file:
            return

        self.excel_file = file

        self.lbl_file.setText(Path(file).name)
        self.lbl_file.setToolTip(file)

        self.logger.info(f"Excel selected : {file}")

    # =====================================================
    # START
    # =====================================================

    def start_upload(self):

        if not self.excel_file:

            self.append_log("Silakan pilih file Excel terlebih dahulu.")
            return

        if self.thread is not None:

            self.append_log("Upload sedang berjalan.")
            return

        self.progress.setValue(0)

        self.btn_start.setEnabled(False)
        self.btn_browse.setEnabled(False)

        self.thread = QThread()

        self.worker = UploadWorker(
            self.context,
            self.excel_file
        )

        self.worker.moveToThread(self.thread)

        self.thread.started.connect(
            self.worker.run
        )

        self.worker.progress.connect(
            self.progress.setValue
        )

        self.worker.status.connect(
            self.lbl_file.setText
        )

        self.worker.log.connect(
            self.append_log
        )

        self.worker.finished.connect(
            self.thread.quit
        )

        self.worker.finished.connect(
            self.worker.deleteLater
        )

        self.thread.finished.connect(
            self.thread.deleteLater
        )

        self.thread.finished.connect(
            self.upload_finished
        )

        self.thread.start()

    # =====================================================
    # STOP
    # =====================================================

    def stop_upload(self):

        if self.worker:

            self.worker.stop()

            self.logger.warning(
                "Stop requested."
            )

            self.append_log(
                "STOP REQUESTED"
            )

    # =====================================================
    # FINISHED
    # =====================================================

    def upload_finished(self):

        self.btn_start.setEnabled(True)
        self.btn_browse.setEnabled(True)

        self.worker = None
        self.thread = None

    # =====================================================
    # LOG
    # =====================================================

    def append_log(self, text):

        self.log.append(text)
        self.log.ensureCursorVisible()