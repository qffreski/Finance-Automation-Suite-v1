from PySide6.QtWidgets import (
    QMainWindow,
    QTabWidget
)

from gui.upload_page import UploadPage
from gui.setting_page import SettingPage


class MainWindow(QMainWindow):

    def __init__(self, context):

        super().__init__()

        self.context = context

        self.setWindowTitle("Finance Automation Suite")
        self.resize(1200, 700)
        self.setMinimumSize(1000, 650)

        self.init_ui()

    # =====================================================
    # UI
    # =====================================================

    def init_ui(self):

        self.tabs = QTabWidget()
        self.tabs.setObjectName("mainTabs")

        self.tabs.addTab(
            UploadPage(self.context),
            "Upload"
        )

        self.tabs.addTab(
            SettingPage(self.context),
            "Settings"
        )

        self.setCentralWidget(self.tabs)