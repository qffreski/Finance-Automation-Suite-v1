import time
import pyautogui


class CalibrationTool:

    def __init__(self, config, logger):

        self.config = config
        self.logger = logger

    # =====================================================
    # CAPTURE POSITION
    # =====================================================

    def capture(
        self,
        key,
        progress_callback=None,
        status_callback=None
    ):
        """
        Capture posisi mouse.

        Parameters
        ----------
        key : str
            Nama koordinat.

        progress_callback : callable(int), optional
            Callback countdown (5..1)

        status_callback : callable(str), optional
            Callback status proses.
        """

        self.logger.info(f"Calibration start : {key}")

        if status_callback:
            status_callback(f"Capture '{key}' dimulai.")

        delay = self.config.get_float(
            "countdown_delay",
            1
        )

        # ==========================
        # COUNTDOWN
        # ==========================

        for i in range(5, 0, -1):

            if progress_callback:
                progress_callback(i)

            self.logger.info(
                f"Capture {key} : {i}"
            )

            time.sleep(delay)

        # ==========================
        # GET POSITION
        # ==========================

        x, y = pyautogui.position()

        self.logger.info(
            f"Mouse Position : ({x}, {y})"
        )

        # ==========================
        # SAVE CONFIG
        # ==========================

        self.config.set_position(
            key,
            [x, y]
        )

        self.logger.info(
            f"Calibration saved : {key} -> ({x}, {y})"
        )

        if status_callback:
            status_callback(
                f"Capture '{key}' selesai."
            )

        return x, y