```bat
@echo off
title Finance Automation Suite Builder
color 0A

echo.
echo ==========================================================
echo            FINANCE AUTOMATION SUITE BUILDER
echo ==========================================================
echo.

REM ==========================================================
REM Activate Virtual Environment (optional)
REM ==========================================================

if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
)

REM ==========================================================
REM Clean Old Build
REM ==========================================================

echo [1/5] Cleaning old build...

if exist build (
    rmdir /S /Q build
)

if exist dist (
    rmdir /S /Q dist
)

if exist "__pycache__" (
    rmdir /S /Q __pycache__
)

REM ==========================================================
REM Build EXE
REM ==========================================================

echo.
echo [2/5] Building EXE...
echo.

pyinstaller ^
"Finance Automation Suite.spec" ^
--clean ^
--noconfirm ^
--version-file version_info.txt

if errorlevel 1 (
    color 0C
    echo.
    echo ======================================================
    echo BUILD FAILED
    echo ======================================================
    pause
    exit
)

REM ==========================================================
REM Create Runtime Folders
REM ==========================================================

echo.
echo [3/5] Creating folders...

mkdir "dist\Finance Automation Suite\logs" 2>nul
mkdir "dist\Finance Automation Suite\screenshots" 2>nul

REM ==========================================================
REM Copy Config
REM ==========================================================

echo.
echo [4/5] Copy configuration...

xcopy config "dist\Finance Automation Suite\config\" /E /I /Y >nul

if exist excel (
    xcopy excel "dist\Finance Automation Suite\excel\" /E /I /Y >nul
)

if exist pdf (
    xcopy pdf "dist\Finance Automation Suite\pdf\" /E /I /Y >nul
)

REM ==========================================================
REM Finish
REM ==========================================================

echo.
echo [5/5] Build completed successfully.
echo.

echo ==========================================================
echo OUTPUT:
echo dist\Finance Automation Suite\
echo ==========================================================

start "" "dist\Finance Automation Suite"

color 0A

pause
```
