from pathlib import Path


class Voucher:

    def __init__(self, number: str, pdf: str, size: float):

        # =====================================================
        # CORE DATA
        # =====================================================

        self.number = str(number).strip()
        self.pdf = str(pdf).strip()
        self.size = float(size)

        # =====================================================
        # STATE
        # =====================================================

        self.status = "Waiting"
        self.message = ""

    # =====================================================
    # PROPERTIES
    # =====================================================

    @property
    def pdf_path(self) -> Path:
        return Path(self.pdf)

    def exists(self) -> bool:
        return self.pdf_path.exists()

    # =====================================================
    # VALIDATION
    # =====================================================

    def validate(self):

        if not self.number:
            raise ValueError("Voucher Number kosong.")

        if not self.pdf:
            raise ValueError("Path PDF kosong.")

        if not self.exists():
            raise FileNotFoundError(
                f"PDF tidak ditemukan:\n{self.pdf_path}"
            )

        if self.pdf_path.suffix.lower() != ".pdf":
            raise ValueError(
                f"File bukan PDF:\n{self.pdf_path}"
            )

        if self.size <= 0:
            raise ValueError(
                "Ukuran PDF harus lebih dari 0 KB."
            )

    # =====================================================
    # LIFECYCLE STATE
    # =====================================================

    def start(self):
        self.status = "Running"
        self.message = ""

    def success(self):
        self.status = "Success"
        self.message = "Upload berhasil."

    def failed(self, message: str):
        self.status = "Failed"
        self.message = str(message)

    # =====================================================
    # DEBUG / LOGGING
    # =====================================================

    def __repr__(self):
        return (
            f"Voucher("
            f"number={self.number}, "
            f"status={self.status}, "
            f"pdf={self.pdf})"
        )