import math
import time
import ctypes

import pyautogui
import pyperclip


class KingdeeAutomation:

    def __init__(
        self,
        config,
        logger,
        file_selector,
        stop_checker=None
    ):

        self.config = config
        self.logger = logger
        self.file_selector = file_selector

        self.stop_checker = stop_checker

        ctypes.windll.user32.SetProcessDPIAware()

        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.1

    # =====================================================
    # SET STOP CHECKER
    # =====================================================

    def set_stop_checker(self, checker):

        self.stop_checker = checker

    # =====================================================
    # CHECK STOP
    # =====================================================

    def check_stop(self):

        if self.stop_checker is None:
            return

        if not self.stop_checker():
            raise InterruptedError("Upload dihentikan user.")

    # =====================================================
    # INTERRUPTIBLE SLEEP
    # =====================================================

    def sleep(self, seconds):

        end = time.time() + seconds

        while time.time() < end:

            self.check_stop()

            time.sleep(0.1)

    # =====================================================
    # CLICK
    # =====================================================

    def click(self, key):

        self.check_stop()

        x, y = self.config.get_position(key)

        pyautogui.moveTo(
            x,
            y,
            duration=self.config.get_float("move_duration", 0.25)
        )

        pyautogui.click()

        self.logger.info(f"CLICK : {key} ({x}, {y})")

        self.sleep(
            self.config.get_float("click_delay", 0.8)
        )

    # =====================================================
    # TYPE TEXT
    # =====================================================

    def type_text(self, text):

        self.check_stop()

        pyautogui.hotkey("ctrl", "a")

        self.sleep(
            self.config.get_float("typing_delay", 0.2)
        )

        pyperclip.copy(str(text))

        pyautogui.hotkey("ctrl", "v")

        self.sleep(
            self.config.get_float("typing_delay", 0.2)
        )

        pyautogui.press("enter")

        self.logger.info(f"TYPE : {text}")

        self.sleep(
            self.config.get_float("click_delay", 0.8)
        )

    # =====================================================
    # WAIT UPLOAD
    # =====================================================

    def wait_upload(self, size):

        speed = self.config.get_int(
            "upload_speed",
            250
        )

        seconds = max(
            7,
            math.ceil(float(size) / speed)
        )

        self.logger.info(
            f"WAIT UPLOAD : {seconds}s"
        )

        self.sleep(seconds)

    # =====================================================
    # RESET
    # =====================================================

    def reset(self):

        for key in ("exit2", "error"):

            self.check_stop()

            try:
                self.click(key)

            except Exception as e:
                self.logger.warning(
                    f"RESET SKIP : {key} ({e})"
                )

    # =====================================================
    # SEARCH VOUCHER
    # =====================================================

    def search_voucher(self, voucher):

        self.check_stop()

        self.logger.info(
            f"SEARCH : {voucher.number}"
        )

        self.click("query")

        self.type_text(
            voucher.number
        )

        self.sleep(
            self.config.get_float("search_delay", 3.0)
        )

    # =====================================================
    # OPEN ATTACHMENT
    # =====================================================

    def open_attachment(self):

        for key in (
            "checkbox",
            "option",
            "attachment",
            "new",
            "plus"
        ):

            self.check_stop()

            self.click(key)

        self.sleep(
            self.config.get_float("attachment_delay", 2.0)
        )

    # =====================================================
    # SAVE
    # =====================================================

    def save(self):

        self.check_stop()

        self.logger.info("SAVE START")

        self.click("save")
        self.click("exit1")
        self.click("exit2")

        self.sleep(
            self.config.get_float("save_delay", 1.0)
        )

        self.logger.info("SAVE SUCCESS")

    # =====================================================
    # MAIN FLOW
    # =====================================================

    def upload(self, voucher):

        try:

            self.check_stop()

            self.logger.info("=" * 60)
            self.logger.info(
                f"UPLOAD START : {voucher.number}"
            )
            self.logger.info("=" * 60)

            self.reset()

            self.search_voucher(voucher)

            self.open_attachment()

            success = self.file_selector.select(
                voucher.pdf
            )

            if not success:

                self.logger.error(
                    f"FAILED PDF : {voucher.number}"
                )

                return False

            self.wait_upload(
                voucher.size
            )

            self.save()

            self.logger.info(
                f"SUCCESS : {voucher.number}"
            )

            return True

        except InterruptedError:

            self.logger.warning(
                "UPLOAD STOPPED BY USER"
            )

            return False

        except Exception as e:

            self.logger.exception(e)

            return False