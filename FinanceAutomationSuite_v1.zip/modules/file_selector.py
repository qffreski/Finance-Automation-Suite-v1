import time
from pathlib import Path

import pyautogui
import pyperclip


class FileSelector:

    def __init__(
        self,
        config,
        logger,
        stop_checker=None
    ):

        self.config = config
        self.logger = logger
        self.stop_checker = stop_checker

    # =====================================================
    # SET STOP CHECKER
    # =====================================================

    def set_stop_checker(self, checker):

        self.stop_checker = checker

    # =====================================================
    # CHECK STOP
    # =====================================================

    def check_stop(self):

        if self.stop_checker is None:
            return

        if not self.stop_checker():
            raise InterruptedError(
                "Upload dihentikan user."
            )

    # =====================================================
    # INTERRUPTIBLE SLEEP
    # =====================================================

    def sleep(self, seconds):

        end = time.time() + seconds

        while time.time() < end:

            self.check_stop()

            time.sleep(0.1)

    # =====================================================
    # CLICK
    # =====================================================

    def click(self, key):

        self.check_stop()

        x, y = self.config.get_position(key)

        pyautogui.moveTo(
            x,
            y,
            duration=self.config.get_float(
                "move_duration",
                0.25
            )
        )

        pyautogui.click()

        self.sleep(
            self.config.get_float(
                "click_delay",
                0.8
            )
        )

    # =====================================================
    # SELECT FILE
    # =====================================================

    def select(self, file_path):

        self.check_stop()

        path = Path(
            str(file_path)
            .strip()
            .strip('"')
            .strip("'")
        )

        self.logger.info(
            f"PDF PATH : {path}"
        )

        if not path.exists():

            self.logger.error(
                f"PDF NOT FOUND : {path}"
            )

            return False

        # ============================================
        # FILE NAME
        # ============================================

        self.click("file_name")

        pyautogui.hotkey("ctrl", "a")

        self.sleep(
            self.config.get_float(
                "typing_delay",
                0.2
            )
        )

        pyperclip.copy(str(path))

        pyautogui.hotkey("ctrl", "v")

        self.sleep(
            self.config.get_float(
                "typing_delay",
                0.2
            )
        )

        self.click("open")

        self.sleep(
            self.config.get_float(
                "dialog_delay",
                1.5
            )
        )

        return True