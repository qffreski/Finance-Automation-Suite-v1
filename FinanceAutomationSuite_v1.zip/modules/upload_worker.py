from PySide6.QtCore import QObject, Signal

from modules.excel_reader import ExcelReader


class UploadWorker(QObject):

    finished = Signal()
    progress = Signal(int)
    status = Signal(str)
    log = Signal(str)

    def __init__(self, context, excel_file):

        super().__init__()

        self.context = context
        self.config = context.config
        self.logger = context.logger
        self.automation = context.automation

        self.excel_file = excel_file
        self.running = True

        self.reader = ExcelReader(
            config=self.config,
            logger=self.logger
        )

        # =====================================================
        # STOP CHECKER
        # =====================================================

        self.automation.set_stop_checker(
            lambda: self.running
        )

        self.automation.file_selector.set_stop_checker(
            lambda: self.running
        )

    # =====================================================
    # STOP
    # =====================================================

    def stop(self):

        self.running = False

    # =====================================================
    # RUN
    # =====================================================

    def run(self):

        try:

            vouchers = self.reader.read(
                self.excel_file
            )

            total = len(vouchers)

            if total == 0:
                raise Exception(
                    "Tidak ada voucher di file Excel."
                )

            self.logger.info("=" * 60)
            self.logger.info("Finance Automation Suite")
            self.logger.info("=" * 60)
            self.logger.info(f"Total Voucher : {total}")

            self.status.emit("Starting...")

            self.log.emit("")
            self.log.emit("=" * 60)
            self.log.emit("Finance Automation Suite")
            self.log.emit("=" * 60)
            self.log.emit(f"Total Voucher : {total}")

            # =================================================
            # LOOP
            # =================================================

            for index, voucher in enumerate(
                vouchers,
                start=1
            ):

                if not self.running:

                    self.logger.warning(
                        "Upload dihentikan user."
                    )

                    self.status.emit("Stopped")

                    self.log.emit("")
                    self.log.emit("Upload dihentikan user.")

                    break

                number = voucher.number

                self.status.emit(
                    f"{index}/{total} - {number}"
                )

                self.log.emit("")
                self.log.emit("-" * 60)
                self.log.emit(
                    f"[{index}/{total}] {number}"
                )
                self.log.emit("-" * 60)

                success = self.automation.upload(
                    voucher
                )

                if success:

                    voucher.success()

                    self.logger.info(
                        f"SUCCESS : {number}"
                    )

                    self.log.emit("SUCCESS")

                else:

                    if self.running:

                        voucher.failed(
                            "Upload gagal."
                        )

                        self.logger.error(
                            f"FAILED : {number}"
                        )

                        self.log.emit("FAILED")
                        self.log.emit(
                            voucher.message
                        )

                    else:

                        self.logger.warning(
                            f"STOPPED : {number}"
                        )

                        self.log.emit("STOPPED")

                        break

                percent = int(
                    index / total * 100
                )

                self.progress.emit(
                    percent
                )

            self.status.emit("Finished")

            self.log.emit("")
            self.log.emit("=" * 60)
            self.log.emit("Upload Selesai")
            self.log.emit("=" * 60)

        except InterruptedError:

            self.logger.warning(
                "Upload dihentikan user."
            )

            self.status.emit("Stopped")

            self.log.emit("")
            self.log.emit("Upload dihentikan user.")

        except Exception as e:

            self.logger.exception(e)

            self.status.emit("Error")

            self.log.emit("")
            self.log.emit("=" * 60)
            self.log.emit("ERROR")
            self.log.emit("=" * 60)
            self.log.emit(str(e))

        finally:

            self.finished.emit()