from pathlib import Path

import pandas as pd

from models.voucher import Voucher


class ExcelReader:

    def __init__(self, config, logger):

        self.config = config
        self.logger = logger

    # =====================================================
    # READ EXCEL
    # =====================================================

    def read(self, file_path):

        df = pd.read_excel(file_path)

        required = [
            "VoucherNumber",
            "VoucherPDF",
            "UkuranPDF"
        ]

        missing = [
            c for c in required
            if c not in df.columns
        ]

        if missing:

            raise Exception(
                "Kolom Excel tidak ditemukan : " +
                ", ".join(missing)
            )

        vouchers = []

        for index, row in df.iterrows():

            try:

                # ============================================
                # Voucher Number
                # ============================================

                number = str(
                    row["VoucherNumber"]
                ).strip()

                if number.endswith(".0"):
                    number = number[:-2]

                # ============================================
                # PDF
                # ============================================

                pdf = row["VoucherPDF"]

                if pd.isna(pdf):

                    pdf = ""

                else:

                    pdf = str(pdf).strip().strip('"').strip("'")

                pdf = str(
                    self.config.resolve_pdf(pdf)
                )

                # ============================================
                # SIZE
                # ============================================

                size = row.get(
                    "UkuranPDF",
                    0
                )

                if pd.isna(size):
                    size = 0

                # ============================================
                # AUTO SIZE
                # ============================================

                if Path(pdf).exists():

                    size = (
                        Path(pdf)
                        .stat()
                        .st_size
                        / 1024
                    )

                # ============================================
                # CREATE MODEL
                # ============================================

                voucher = Voucher(
                    number=number,
                    pdf=pdf,
                    size=float(size)
                )

                vouchers.append(voucher)

            except Exception as e:

                self.logger.error(
                    f"SKIP ROW {index + 2} : {e}"
                )

        self.logger.info(
            f"Voucher loaded : {len(vouchers)}"
        )

        return vouchers