from PySide6.QtCore import QObject, Signal

from config.calibration import CalibrationTool


class CalibrationWorker(QObject):
    """
    Worker untuk proses capture koordinat agar GUI tidak freeze.

    Signal:
        started()               : Capture dimulai
        countdown(int)          : Hitung mundur
        finished(int, int)      : Capture berhasil (x, y)
        status(str)             : Status proses
        error(str)              : Error
    """

    started = Signal()
    countdown = Signal(int)
    finished = Signal(int, int)
    status = Signal(str)
    error = Signal(str)

    def __init__(self, context, key):
        super().__init__()

        self.context = context
        self.key = key

        self.tool = CalibrationTool(
            config=context.config,
            logger=context.logger
        )

    def run(self):

        try:

            self.started.emit()
            self.status.emit(
                f"Capture '{self.key}' dimulai."
            )

            x, y = self.tool.capture(
                key=self.key,
                progress_callback=self.countdown.emit
            )

            self.status.emit(
                f"Capture '{self.key}' selesai."
            )

            self.finished.emit(x, y)

        except Exception as e:

            self.error.emit(str(e))