; ======================================================
; Finance Automation Suite Installer (FINAL FIXED)
; ======================================================

#define MyAppName "Finance Automation Suite"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "PT Dwitunggal Perkasa Mandiri"
#define MyAppExeName "Finance Automation Suite.exe"

[Setup]
AppId={{E1A8F08A-FA10-47B5-9D0C-5F6C3F7D1E11}}

AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}

DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}

OutputDir=Installer
OutputBaseFilename=FinanceAutomationSuite_Setup_v1.0

Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin

UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create Desktop Shortcut"; GroupDescription: "Additional Icons:"; Flags: unchecked

[Files]
Source: "dist\Finance Automation Suite\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Finance Automation Suite"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Finance Automation Suite"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Finance Automation Suite"; Flags: nowait postinstall skipifsilent