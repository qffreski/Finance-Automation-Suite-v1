from pathlib import Path
import datetime
import traceback
import threading


class Logger:

    def __init__(self):

        self.log_dir = Path("logs")
        self.log_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        self.file = self.log_dir / "app.log"

        # Thread Safe
        self._lock = threading.Lock()

        # Tampilkan log ke terminal
        self.console = True

    # =====================================================
    # INTERNAL
    # =====================================================

    def _write(self, level, message):

        now = datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        line = f"[{now}] [{level}] {message}"

        if self.console:
            print(line)

        try:

            with self._lock:

                with open(
                    self.file,
                    "a",
                    encoding="utf-8"
                ) as f:

                    f.write(line + "\n")

        except Exception:
            pass

    # =====================================================
    # INFO
    # =====================================================

    def info(self, message):

        self._write(
            "INFO",
            message
        )

    # =====================================================
    # WARNING
    # =====================================================

    def warning(self, message):

        self._write(
            "WARNING",
            message
        )

    # =====================================================
    # ERROR
    # =====================================================

    def error(self, message):

        self._write(
            "ERROR",
            message
        )

    # =====================================================
    # EXCEPTION
    # =====================================================

    def exception(self, exception):

        self._write(
            "EXCEPTION",
            str(exception)
        )

        try:

            tb = traceback.format_exc()

            with self._lock:

                with open(
                    self.file,
                    "a",
                    encoding="utf-8"
                ) as f:

                    f.write(tb + "\n")

        except Exception:
            pass

    # =====================================================
    # TITLE
    # =====================================================

    def title(self, text):

        self.info("=" * 60)
        self.info(text)
        self.info("=" * 60)

    # =====================================================
    # SEPARATOR
    # =====================================================

    def separator(self):

        self.info("-" * 60)

    # =====================================================
    # COMPATIBILITY
    # =====================================================

    def write(self, message):

        self.info(message)