git clone <repository>
cd "Finance Automation Suite"

python -m venv .venv

# Windows
.\.venv\Scripts\activate

pip install --upgrade pip
pip install -r requirements.txt

python main.py